package in.volexmc.skydungeons.dungeon;

import java.util.ArrayList;
import java.util.List;

public class Dungeon {

    private final String id;
    private final String name;
    private final String theme;
    private final int minPlayers;
    private final int maxPlayers;
    private final int difficulty;

    private final List<DungeonStage> stages;

    public Dungeon(
            String id,
            String name,
            String theme,
            int minPlayers,
            int maxPlayers,
            int difficulty
    ) {
        this.id = id;
        this.name = name;
        this.theme = theme;
        this.minPlayers = minPlayers;
        this.maxPlayers = maxPlayers;
        this.difficulty = difficulty;

        this.stages = new ArrayList<>();
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getTheme() {
        return theme;
    }

    public int getMinPlayers() {
        return minPlayers;
    }

    public int getMaxPlayers() {
        return maxPlayers;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public void addStage(
            DungeonStage stage
    ) {
        stages.add(stage);
    }

    public List<DungeonStage> getStages() {
        return stages;
    }

    public DungeonStage getStage(
            int stageNumber
    ) {
        for (DungeonStage stage : stages) {

            if (stage.getStage() == stageNumber) {
                return stage;
            }
        }

        return null;
    }

    public int getStageCount() {
        return stages.size();
    }
}