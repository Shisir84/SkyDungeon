package in.volexmc.skydungeons.dungeon;

public class StageObjective {

    private final String objectiveId;
    private final String name;
    private final int requiredAmount;

    private int currentAmount;

    public StageObjective(
            String objectiveId,
            String name,
            int requiredAmount
    ) {
        this.objectiveId = objectiveId;
        this.name = name;
        this.requiredAmount = requiredAmount;
        this.currentAmount = 0;
    }

    public String getObjectiveId() {
        return objectiveId;
    }

    public String getName() {
        return name;
    }

    public int getRequiredAmount() {
        return requiredAmount;
    }

    public int getCurrentAmount() {
        return currentAmount;
    }

    public boolean addProgress(int amount) {

        if (amount <= 0) {
            return false;
        }

        if (isCompleted()) {
            return false;
        }

        currentAmount += amount;

        if (currentAmount > requiredAmount) {
            currentAmount = requiredAmount;
        }

        return true;
    }

    public boolean isCompleted() {
        return currentAmount >= requiredAmount;
    }

    public double getProgress() {

        if (requiredAmount <= 0) {
            return 1.0;
        }

        return (double) currentAmount
                / requiredAmount;
    }

    public String getProgressText() {

        return currentAmount
                + "/"
                + requiredAmount;
    }

    public void reset() {
        currentAmount = 0;
    }
}