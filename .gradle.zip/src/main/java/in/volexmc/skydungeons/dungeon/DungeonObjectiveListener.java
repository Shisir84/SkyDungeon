package in.volexmc.skydungeons.dungeon;

import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataType;
import in.volexmc.skydungeons.SkyDungeons;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

import java.util.UUID;

public class DungeonObjectiveListener implements Listener {

    private final SkyDungeons plugin;

    public DungeonObjectiveListener(SkyDungeons plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {

        LivingEntity entity = event.getEntity();

        NamespacedKey dungeonMobKey =
                new NamespacedKey(
                        "skydungeons",
                        "dungeon_mob"
                );

        Byte dungeonMob =
                entity.getPersistentDataContainer().get(
                        dungeonMobKey,
                        PersistentDataType.BYTE
                );

        if (dungeonMob == null || dungeonMob != (byte) 1) {
            return;
        }

        Player killer = entity.getKiller();

        if (killer == null) {
            return;
        }

        // ... baaki existing code

        DungeonInstance instance =
                plugin.getDungeonInstanceManager()
                        .getInstanceForPlayer(killer);

        if (instance == null) {
            return;
        }

        StageObjective objective =
                instance.getCurrentObjective();

        if (objective == null) {
            return;
        }

        if (!objective.getObjectiveId().equals("kill_warden_mobs")) {
            return;
        }

        if (objective.isCompleted()) {
            return;
        }

        instance.addObjectiveProgress(1);

        int current = objective.getCurrentAmount();
        int required = objective.getRequiredAmount();

        for (UUID uuid : instance.getPlayers()) {

            Player player =
                    plugin.getServer()
                            .getPlayer(uuid);

            if (player != null) {

                player.sendMessage(
                        "§8[§5SkyDungeons§8] §d"
                                + objective.getName()
                                + " §7"
                                + current
                                + "/"
                                + required
                );
            }
        }

        if (objective.isCompleted()) {

            completeObjective(instance);
        }
    }

    private void completeObjective(DungeonInstance instance) {

        for (UUID uuid : instance.getPlayers()) {

            Player player =
                    plugin.getServer()
                            .getPlayer(uuid);

            if (player != null) {

                player.sendMessage("");
                player.sendMessage(
                        "§a§lOBJECTIVE COMPLETE!"
                );
                player.sendMessage(
                        "§7"
                                + instance.getCurrentObjective()
                                .getName()
                                + " §acompleted!"
                );
                player.sendMessage("");
            }
        }

        /*
         * Move to the next stage.
         */
        if (instance.isFinalStage()) {

            for (UUID uuid : instance.getPlayers()) {

                Player player =
                        plugin.getServer()
                                .getPlayer(uuid);

                if (player != null) {

                    player.sendMessage(
                            "§6§lDUNGEON COMPLETE!"
                    );
                }
            }

            return;
        }

        boolean advanced =
                instance.advanceStage();

        if (!advanced) {
            return;
        }

        for (UUID uuid : instance.getPlayers()) {

            Player player =
                    plugin.getServer()
                            .getPlayer(uuid);

            if (player != null) {

                StageObjective next =
                        instance.getCurrentObjective();

                player.sendMessage(
                        "§e§lNEXT STAGE!"
                );

                if (next != null) {

                    player.sendMessage(
                            "§7Objective: §f"
                                    + next.getName()
                                    + " §7("
                                    + next.getProgressText()
                                    + ")"
                    );
                }
            }
        }
    }
}