package in.volexmc.skydungeons.dungeon;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.WorldType;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class DungeonInstanceManager {

    private final Map<UUID, DungeonInstance> instances = new HashMap<>();

    private final File serverFolder;
    private final File templateFolder;

    public DungeonInstanceManager() {

        serverFolder = Bukkit.getWorldContainer();

        templateFolder =
                new File(
                        serverFolder,
                        "dungeon_templates"
                );

        if (!templateFolder.exists()) {
            templateFolder.mkdirs();
        }
    }

    public DungeonInstance createInstance(Dungeon dungeon) {

        File template =
                new File(
                        templateFolder,
                        dungeon.getId()
                );

        if (!template.exists()) {

            Bukkit.getLogger().warning(
                    "Dungeon template not found: "
                            + template.getAbsolutePath()
            );

            return null;
        }

        String worldName =
                "sd_"
                        + dungeon.getId()
                        + "_"
                        + UUID.randomUUID()
                        .toString()
                        .substring(0, 8);

        File instanceFolder =
                new File(
                        serverFolder,
                        worldName
                );

        try {

            copyDirectory(
                    template.toPath(),
                    instanceFolder.toPath()
            );

        } catch (Exception exception) {

            Bukkit.getLogger().severe(
                    "Could not copy dungeon template: "
                            + exception.getMessage()
            );

            deleteDirectory(instanceFolder);

            return null;
        }

        deleteFile(
                new File(
                        instanceFolder,
                        "session.lock"
                )
        );

        deleteFile(
                new File(
                        instanceFolder,
                        "uid.dat"
                )
        );

        World world =
                new WorldCreator(worldName)
                        .type(WorldType.NORMAL)
                        .createWorld();

        if (world == null) {

            Bukkit.getLogger().severe(
                    "Could not load dungeon world: "
                            + worldName
            );

            deleteDirectory(instanceFolder);

            return null;
        }

        DungeonInstance instance =
                new DungeonInstance(
                        dungeon,
                        worldName
                );

        instances.put(
                instance.getInstanceId(),
                instance
        );

        Bukkit.getLogger().info(
                "Created dungeon instance: "
                        + worldName
        );

        return instance;
    }

    public DungeonInstance getInstance(UUID instanceId) {
        return instances.get(instanceId);
    }

    public Map<UUID, DungeonInstance> getInstances() {
        return instances;
    }

    public int getInstanceCount() {
        return instances.size();
    }

    /*
     * Find the dungeon instance containing a player.
     */
    public DungeonInstance getInstanceForPlayer(UUID playerId) {

        for (DungeonInstance instance : instances.values()) {

            if (instance.hasPlayer(playerId)) {
                return instance;
            }
        }

        return null;
    }

    public DungeonInstance getInstanceForPlayer(
            org.bukkit.entity.Player player
    ) {

        return getInstanceForPlayer(
                player.getUniqueId()
        );
    }

    public void removeInstance(UUID instanceId) {

        DungeonInstance instance =
                instances.remove(instanceId);

        if (instance == null) {
            return;
        }

        World world =
                Bukkit.getWorld(
                        instance.getWorldName()
                );

        if (world != null) {

            Bukkit.unloadWorld(
                    world,
                    false
            );
        }

        File worldFolder =
                new File(
                        serverFolder,
                        instance.getWorldName()
                );

        deleteDirectory(worldFolder);

        Bukkit.getLogger().info(
                "Removed dungeon instance: "
                        + instance.getWorldName()
        );
    }

    public void removeAllInstances() {

        UUID[] ids =
                instances.keySet()
                        .toArray(
                                new UUID[0]
                        );

        for (UUID id : ids) {
            removeInstance(id);
        }
    }

    private void copyDirectory(
            Path source,
            Path destination
    ) throws IOException {

        try (var stream = Files.walk(source)) {

            stream.forEach(path -> {

                try {

                    Path relative =
                            source.relativize(path);

                    Path target =
                            destination.resolve(relative);

                    if (Files.isDirectory(path)) {

                        Files.createDirectories(
                                target
                        );

                    } else {

                        Path parent =
                                target.getParent();

                        if (parent != null) {
                            Files.createDirectories(
                                    parent
                            );
                        }

                        Files.copy(
                                path,
                                target,
                                StandardCopyOption.REPLACE_EXISTING
                        );
                    }

                } catch (IOException exception) {

                    throw new RuntimeException(
                            exception
                    );
                }
            });
        }
    }

    private void deleteDirectory(
            File directory
    ) {

        if (directory == null
                || !directory.exists()) {

            return;
        }

        File[] files =
                directory.listFiles();

        if (files != null) {

            for (File file : files) {

                if (file.isDirectory()) {

                    deleteDirectory(file);

                } else {

                    deleteFile(file);
                }
            }
        }

        deleteFile(directory);
    }

    private void deleteFile(
            File file
    ) {

        if (file != null
                && file.exists()) {

            try {

                Files.deleteIfExists(
                        file.toPath()
                );

            } catch (IOException exception) {

                Bukkit.getLogger().warning(
                        "Could not delete "
                                + file.getAbsolutePath()
                );
            }
        }
    }
}