package in.volexmc.skydungeons.dungeon;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class DungeonInstance {

    private final UUID instanceId;
    private final Dungeon dungeon;
    private final String worldName;
    private final Set<UUID> players;

    private final long startTime;

    private int currentStage;

    // Instance-specific objective
    private StageObjective currentObjective;

    public DungeonInstance(Dungeon dungeon, String worldName) {

        this.instanceId = UUID.randomUUID();
        this.dungeon = dungeon;
        this.worldName = worldName;
        this.players = new HashSet<>();
        this.startTime = System.currentTimeMillis();

        // Dungeon starts from Stage 1
        this.currentStage = 1;

        // Load Stage 1 objective
        loadCurrentObjective();
    }

    public UUID getInstanceId() {
        return instanceId;
    }

    public Dungeon getDungeon() {
        return dungeon;
    }

    public String getWorldName() {
        return worldName;
    }

    public Set<UUID> getPlayers() {
        return players;
    }

    public long getStartTime() {
        return startTime;
    }

    public void addPlayer(UUID player) {
        players.add(player);
    }

    public void removePlayer(UUID player) {
        players.remove(player);
    }

    public boolean hasPlayer(UUID player) {
        return players.contains(player);
    }

    public int getPlayerCount() {
        return players.size();
    }

    public int getCurrentStage() {
        return currentStage;
    }

    public boolean setCurrentStage(int stage) {

        if (stage < 1 || stage > dungeon.getStageCount()) {
            return false;
        }

        this.currentStage = stage;

        // New stage gets a fresh objective
        loadCurrentObjective();

        return true;
    }

    public boolean advanceStage() {

        if (currentStage >= dungeon.getStageCount()) {
            return false;
        }

        currentStage++;

        // Load next stage objective
        loadCurrentObjective();

        return true;
    }

    public boolean isFinalStage() {
        return currentStage >= dungeon.getStageCount();
    }

    /*
     * =========================
     * OBJECTIVE SYSTEM
     * =========================
     */

    private void loadCurrentObjective() {

        DungeonStage stage = dungeon.getStage(currentStage);

        if (stage == null) {
            currentObjective = null;
            return;
        }

        /*
         * Temporary Stage 1 objective.
         *
         * Later this will come from config:
         * mobs, bosses, rooms, timers, etc.
         */

        if (currentStage == 1) {

            currentObjective = new StageObjective(
                    "kill_warden_mobs",
                    "Defeat Warden mobs",
                    5
            );

        } else {

            currentObjective = new StageObjective(
                    "stage_objective",
                    "Complete the stage",
                    1
            );
        }
    }

    public StageObjective getCurrentObjective() {
        return currentObjective;
    }

    public boolean addObjectiveProgress(int amount) {

        if (currentObjective == null) {
            return false;
        }

        return currentObjective.addProgress(amount);
    }

    public boolean isObjectiveCompleted() {

        return currentObjective != null
                && currentObjective.isCompleted();
    }
}