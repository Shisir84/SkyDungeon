package in.volexmc.skydungeons.dungeon;

public class DungeonStage {

    private final int stage;
    private final String id;
    private final String name;

    private boolean completed;

    public DungeonStage(
            int stage,
            String id,
            String name
    ) {
        this.stage = stage;
        this.id = id;
        this.name = name;
        this.completed = false;
    }

    public int getStage() {
        return stage;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(
            boolean completed
    ) {
        this.completed = completed;
    }
}