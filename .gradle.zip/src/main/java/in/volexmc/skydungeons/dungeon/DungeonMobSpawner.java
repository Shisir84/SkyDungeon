package in.volexmc.skydungeons.dungeon;

import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Zombie;
import org.bukkit.persistence.PersistentDataType;

public class DungeonMobSpawner {

    public static void spawnStageOneMobs(DungeonInstance instance) {

        World world = org.bukkit.Bukkit.getWorld(
                instance.getWorldName()
        );

        if (world == null) {
            return;
        }

        Location center = world.getSpawnLocation();

        NamespacedKey dungeonMobKey =
                new NamespacedKey(
                        "skydungeons",
                        "dungeon_mob"
                );

        for (int i = 0; i < 5; i++) {

            Location spawnLocation = center.clone().add(
                    (i - 2) * 2.0,
                    0,
                    4
            );

            Zombie zombie = (Zombie) world.spawnEntity(
                    spawnLocation,
                    EntityType.ZOMBIE
            );

            zombie.setCustomName("§5Dungeon Mob");
            zombie.setCustomNameVisible(true);
            zombie.setRemoveWhenFarAway(false);

            // Mark this entity as a SkyDungeons mob
            zombie.getPersistentDataContainer().set(
                    dungeonMobKey,
                    PersistentDataType.BYTE,
                    (byte) 1
            );
        }
    }
}