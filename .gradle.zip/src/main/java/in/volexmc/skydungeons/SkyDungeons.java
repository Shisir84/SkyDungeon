package in.volexmc.skydungeons;

import in.volexmc.skydungeons.dungeon.DungeonMobSpawner;
import in.volexmc.skydungeons.dungeon.Dungeon;
import in.volexmc.skydungeons.dungeon.DungeonInstance;
import in.volexmc.skydungeons.dungeon.DungeonInstanceManager;
import in.volexmc.skydungeons.dungeon.DungeonManager;
import in.volexmc.skydungeons.dungeon.DungeonStage;
import in.volexmc.skydungeons.party.Party;
import in.volexmc.skydungeons.party.PartyInviteManager;
import in.volexmc.skydungeons.party.PartyManager;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.WorldType;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class SkyDungeons extends JavaPlugin implements TabExecutor {

    private PartyManager partyManager;
    private PartyInviteManager partyInviteManager;

    private DungeonManager dungeonManager;
    private DungeonInstanceManager dungeonInstanceManager;

    @Override
    public void onEnable() {

        getLogger().info("=================================");
        getLogger().info("       SkyDungeons Starting");
        getLogger().info("=================================");

        partyManager = new PartyManager();
        partyInviteManager = new PartyInviteManager();

        dungeonManager = new DungeonManager();
        dungeonInstanceManager = new DungeonInstanceManager();

        registerDefaultDungeons();

        if (getCommand("skydungeons") != null) {

            getCommand("skydungeons").setExecutor(this);
            getCommand("skydungeons").setTabCompleter(this);
        }

        getLogger().info(
                "Loaded "
                        + dungeonManager.getDungeonCount()
                        + " dungeons."
        );

        getLogger().info("SkyDungeons enabled successfully!");
    }

    @Override
    public void onDisable() {

        getLogger().info("SkyDungeons shutting down...");

        if (dungeonInstanceManager != null) {
            dungeonInstanceManager.removeAllInstances();
        }

        getLogger().info("SkyDungeons disabled.");
    }

    // =========================================================
    // DEFAULT DUNGEONS
    // =========================================================

    private void registerDefaultDungeons() {

        // =====================================================
        // WARDEN CITY
        // =====================================================

        Dungeon wardenCity =
                new Dungeon(
                        "warden_city",
                        "Warden City",
                        "WARDEN",
                        1,
                        5,
                        1
                );

        wardenCity.addStage(
                new DungeonStage(
                        1,
                        "entrance",
                        "Warden City Entrance"
                )
        );

        wardenCity.addStage(
                new DungeonStage(
                        2,
                        "sculk_guards",
                        "Sculk Guard District"
                )
        );

        wardenCity.addStage(
                new DungeonStage(
                        3,
                        "ancient_city",
                        "Ancient City"
                )
        );

        wardenCity.addStage(
                new DungeonStage(
                        4,
                        "warden_temple",
                        "Warden Temple"
                )
        );

        wardenCity.addStage(
                new DungeonStage(
                        5,
                        "warden_arena",
                        "Warden Arena"
                )
        );

        wardenCity.addStage(
                new DungeonStage(
                        6,
                        "final_boss",
                        "Warden Final Boss"
                )
        );

        dungeonManager.registerDungeon(
                wardenCity
        );

        // =====================================================
        // SKY DUNGEON
        // =====================================================

        Dungeon skyDungeon =
                new Dungeon(
                        "sky_dungeon",
                        "Sky Dungeon",
                        "SKY",
                        1,
                        5,
                        2
                );

        dungeonManager.registerDungeon(
                skyDungeon
        );

        // =====================================================
        // END DUNGEON
        // =====================================================

        Dungeon endDungeon =
                new Dungeon(
                        "end_dungeon",
                        "End Dungeon",
                        "END",
                        1,
                        5,
                        3
                );

        dungeonManager.registerDungeon(
                endDungeon
        );
    }

    // =========================================================
    // MAIN COMMAND
    // =========================================================

    @Override
    public boolean onCommand(
            CommandSender sender,
            Command command,
            String label,
            String[] args
    ) {

        if (!command.getName()
                .equalsIgnoreCase("skydungeons")) {

            return false;
        }

        if (args.length == 0) {

            sendHelp(sender);

            return true;
        }

        String subCommand =
                args[0].toLowerCase();

        // -----------------------------------------------------
        // HELP
        // -----------------------------------------------------

        if (subCommand.equals("help")) {

            sendHelp(sender);

            return true;
        }

        // -----------------------------------------------------
        // LIST
        // -----------------------------------------------------

        if (subCommand.equals("list")) {

            sendDungeonList(sender);

            return true;
        }

        // -----------------------------------------------------
        // STAGES
        // -----------------------------------------------------

        if (subCommand.equals("stages")) {

            handleStagesCommand(sender, args);

            return true;
        }

        // -----------------------------------------------------
        // PARTY
        // -----------------------------------------------------

        if (subCommand.equals("party")) {

            handlePartyCommand(sender, args);

            return true;
        }

        // -----------------------------------------------------
        // ENTER
        // -----------------------------------------------------

        if (subCommand.equals("enter")) {

            handleDungeonEnter(sender, args);

            return true;
        }

        // -----------------------------------------------------
        // TEMPLATE
        // -----------------------------------------------------

        if (subCommand.equals("template")) {

            handleTemplateCommand(sender, args);

            return true;
        }

        sender.sendMessage(
                ChatColor.RED
                        + "Unknown command."
        );

        sendHelp(sender);

        return true;
    }

    // =========================================================
    // HELP
    // =========================================================

    private void sendHelp(
            CommandSender sender
    ) {

        sender.sendMessage(
                ChatColor.DARK_AQUA
                        + "========== SkyDungeons =========="
        );

        sender.sendMessage(
                ChatColor.AQUA
                        + "/skydungeons list"
                        + ChatColor.GRAY
                        + " - List dungeons"
        );

        sender.sendMessage(
                ChatColor.AQUA
                        + "/skydungeons stages <id>"
                        + ChatColor.GRAY
                        + " - List dungeon stages"
        );

        sender.sendMessage(
                ChatColor.AQUA
                        + "/skydungeons enter <id>"
                        + ChatColor.GRAY
                        + " - Enter dungeon"
        );

        sender.sendMessage(
                ChatColor.AQUA
                        + "/skydungeons party create"
        );

        sender.sendMessage(
                ChatColor.AQUA
                        + "/skydungeons party invite <player>"
        );

        sender.sendMessage(
                ChatColor.AQUA
                        + "/skydungeons party accept"
        );

        sender.sendMessage(
                ChatColor.AQUA
                        + "/skydungeons party leave"
        );

        sender.sendMessage(
                ChatColor.AQUA
                        + "/skydungeons party kick <player>"
        );

        sender.sendMessage(
                ChatColor.AQUA
                        + "/skydungeons party promote <player>"
        );

        sender.sendMessage(
                ChatColor.DARK_GRAY
                        + "-------------------------------"
        );

        sender.sendMessage(
                ChatColor.YELLOW
                        + "/skydungeons template create <id>"
        );

        sender.sendMessage(
                ChatColor.YELLOW
                        + "/skydungeons template save <id>"
        );
    }

    // =========================================================
    // DUNGEON LIST
    // =========================================================

    private void sendDungeonList(
            CommandSender sender
    ) {

        sender.sendMessage(
                ChatColor.DARK_AQUA
                        + "========== Dungeons =========="
        );

        for (Dungeon dungeon :
                dungeonManager.getDungeons()) {

            sender.sendMessage(
                    ChatColor.AQUA
                            + dungeon.getId()
                            + ChatColor.GRAY
                            + " | "
                            + ChatColor.WHITE
                            + dungeon.getName()
                            + ChatColor.GRAY
                            + " | Theme: "
                            + ChatColor.YELLOW
                            + dungeon.getTheme()
                            + ChatColor.GRAY
                            + " | Players: "
                            + ChatColor.GREEN
                            + dungeon.getMinPlayers()
                            + "-"
                            + dungeon.getMaxPlayers()
                            + ChatColor.GRAY
                            + " | Stages: "
                            + ChatColor.WHITE
                            + dungeon.getStageCount()
            );
        }

        sender.sendMessage(
                ChatColor.GRAY
                        + "Total dungeons: "
                        + dungeonManager.getDungeonCount()
        );
    }

    // =========================================================
    // STAGES COMMAND
    // =========================================================

    private void handleStagesCommand(
            CommandSender sender,
            String[] args
    ) {

        if (args.length < 2) {

            sender.sendMessage(
                    ChatColor.RED
                            + "Usage: /skydungeons stages <id>"
            );

            return;
        }

        String dungeonId =
                args[1].toLowerCase();

        Dungeon dungeon =
                dungeonManager.getDungeon(dungeonId);

        if (dungeon == null) {

            sender.sendMessage(
                    ChatColor.RED
                            + "Dungeon not found: "
                            + dungeonId
            );

            return;
        }

        sender.sendMessage(
                ChatColor.DARK_AQUA
                        + "========== "
                        + dungeon.getName()
                        + " Stages =========="
        );

        if (dungeon.getStages().isEmpty()) {

            sender.sendMessage(
                    ChatColor.GRAY
                            + "No stages configured."
            );

            return;
        }

        for (DungeonStage stage :
                dungeon.getStages()) {

            ChatColor status =
                    stage.isCompleted()
                            ? ChatColor.GREEN
                            : ChatColor.YELLOW;

            String completedText =
                    stage.isCompleted()
                            ? "Completed"
                            : "Not Completed";

            sender.sendMessage(
                    ChatColor.AQUA
                            + "Stage "
                            + stage.getStage()
                            + ChatColor.GRAY
                            + " | "
                            + ChatColor.WHITE
                            + stage.getName()
                            + ChatColor.GRAY
                            + " | ID: "
                            + ChatColor.YELLOW
                            + stage.getId()
                            + ChatColor.GRAY
                            + " | "
                            + status
                            + completedText
            );
        }
    }

    // =========================================================
    // DUNGEON ENTER
    // =========================================================

    private void handleDungeonEnter(
            CommandSender sender,
            String[] args
    ) {

        if (!(sender instanceof Player player)) {

            sender.sendMessage(
                    ChatColor.RED
                            + "Only players can enter dungeons."
            );

            return;
        }

        if (args.length < 2) {

            player.sendMessage(
                    ChatColor.RED
                            + "Usage: /skydungeons enter <id>"
            );

            return;
        }

        String dungeonId =
                args[1].toLowerCase();

        Dungeon dungeon =
                dungeonManager.getDungeon(dungeonId);

        if (dungeon == null) {

            player.sendMessage(
                    ChatColor.RED
                            + "Dungeon not found: "
                            + dungeonId
            );

            return;
        }

        Party party =
                partyManager.getParty(player);

        if (party == null) {

            player.sendMessage(
                    ChatColor.RED
                            + "You are not in a party."
            );

            player.sendMessage(
                    ChatColor.YELLOW
                            + "Create one with "
                            + ChatColor.WHITE
                            + "/skydungeons party create"
            );

            return;
        }

        if (!party.isLeader(player)) {

            player.sendMessage(
                    ChatColor.RED
                            + "Only the party leader can start a dungeon."
            );

            return;
        }

        int partySize =
                party.getSize();

        if (partySize < dungeon.getMinPlayers()) {

            player.sendMessage(
                    ChatColor.RED
                            + "Your party needs at least "
                            + dungeon.getMinPlayers()
                            + " players."
            );

            return;
        }

        if (partySize > dungeon.getMaxPlayers()) {

            player.sendMessage(
                    ChatColor.RED
                            + "This dungeon allows maximum "
                            + dungeon.getMaxPlayers()
                            + " players."
            );

            return;
        }

        player.sendMessage(
                ChatColor.YELLOW
                        + "Creating private dungeon instance..."
        );

        DungeonInstance instance =
                dungeonInstanceManager.createInstance(
                        dungeon
                );

        if (instance == null) {

            player.sendMessage(
                    ChatColor.RED
                            + "Failed to create dungeon instance."
            );

            player.sendMessage(
                    ChatColor.GRAY
                            + "Make sure this template exists:"
            );

            player.sendMessage(
                    ChatColor.WHITE
                            + "dungeon_templates/"
                            + dungeon.getId()
            );

            return;
        }

        // Add party members
        for (UUID uuid :
                party.getMembers()) {

            instance.addPlayer(uuid);
        }

        // Spawn Stage 1 mobs
        DungeonMobSpawner.spawnStageOneMobs(instance);

        // Get instance world
        World world =
                Bukkit.getWorld(
                        instance.getWorldName()
                );

        if (world == null) {

            player.sendMessage(
                    ChatColor.RED
                            + "Dungeon world could not be loaded."
            );

            dungeonInstanceManager.removeInstance(
                    instance.getInstanceId()
            );

            return;
        }

        Location spawn =
                world.getSpawnLocation();

        // Teleport all party members
        for (UUID uuid :
                party.getMembers()) {

            Player member =
                    Bukkit.getPlayer(uuid);

            if (member == null) {
                continue;
            }

            member.teleport(spawn);

            member.sendMessage(
                    ChatColor.GREEN
                            + "You entered "
                            + ChatColor.WHITE
                            + dungeon.getName()
                            + ChatColor.GREEN
                            + "!"
            );

            member.sendMessage(
                    ChatColor.GRAY
                            + "Stage 1: "
                            + ChatColor.WHITE
                            + "Warden City Entrance"
            );
        }

        player.sendMessage(
                ChatColor.GREEN
                        + "Private dungeon created!"
        );

        player.sendMessage(
                ChatColor.GRAY
                        + "Instance: "
                        + ChatColor.WHITE
                        + instance.getWorldName()
        );
    }

    // =========================================================
    // PARTY COMMAND
    // =========================================================

    private void handlePartyCommand(
            CommandSender sender,
            String[] args
    ) {

        if (!(sender instanceof Player player)) {

            sender.sendMessage(
                    ChatColor.RED
                            + "Only players can use party commands."
            );

            return;
        }

        if (args.length < 2) {

            sendPartyHelp(player);

            return;
        }

        String action =
                args[1].toLowerCase();

        // CREATE
        if (action.equals("create")) {

            Party party =
                    partyManager.createParty(player);

            if (party == null) {

                player.sendMessage(
                        ChatColor.RED
                                + "You are already in a party."
                );

                return;
            }

            player.sendMessage(
                    ChatColor.GREEN
                            + "Party created!"
            );

            player.sendMessage(
                    ChatColor.GRAY
                            + "Invite players using "
                            + ChatColor.WHITE
                            + "/skydungeons party invite <player>"
            );

            return;
        }

        // INVITE
        if (action.equals("invite")) {

            if (args.length < 3) {

                player.sendMessage(
                        ChatColor.RED
                                + "Usage: /skydungeons party invite <player>"
                );

                return;
            }

            Party party =
                    partyManager.getParty(player);

            if (party == null) {

                player.sendMessage(
                        ChatColor.RED
                                + "You are not in a party."
                );

                return;
            }

            if (!party.isLeader(player)) {

                player.sendMessage(
                        ChatColor.RED
                                + "Only the party leader can invite."
                );

                return;
            }

            if (party.getSize() >= 5) {

                player.sendMessage(
                        ChatColor.RED
                                + "Party is full. Maximum 5 players."
                );

                return;
            }

            Player target =
                    Bukkit.getPlayer(args[2]);

            if (target == null) {

                player.sendMessage(
                        ChatColor.RED
                                + "Player is not online."
                );

                return;
            }

            if (target.equals(player)) {

                player.sendMessage(
                        ChatColor.RED
                                + "You cannot invite yourself."
                );

                return;
            }

            if (partyManager.getParty(target) != null) {

                player.sendMessage(
                        ChatColor.RED
                                + "That player is already in a party."
                );

                return;
            }

            partyInviteManager.invite(
                    target,
                    party
            );

            player.sendMessage(
                    ChatColor.GREEN
                            + "Party invitation sent to "
                            + target.getName()
            );

            target.sendMessage(
                    ChatColor.YELLOW
                            + player.getName()
                            + " invited you to a party."
            );

            target.sendMessage(
                    ChatColor.GREEN
                            + "Use "
                            + ChatColor.WHITE
                            + "/skydungeons party accept"
                            + ChatColor.GREEN
                            + " to join."
            );

            return;
        }

        // ACCEPT
        if (action.equals("accept")) {

            Party party =
                    partyInviteManager.getInvitation(player);

            if (party == null) {

                player.sendMessage(
                        ChatColor.RED
                                + "You do not have a party invitation."
                );

                return;
            }

            if (party.getSize() >= 5) {

                player.sendMessage(
                        ChatColor.RED
                                + "That party is already full."
                );

                partyInviteManager.removeInvitation(
                        player
                );

                return;
            }

            boolean added =
                    partyManager.addPlayer(
                            party,
                            player
                    );

            if (!added) {

                player.sendMessage(
                        ChatColor.RED
                                + "Could not join the party."
                );

                return;
            }

            partyInviteManager.removeInvitation(
                    player
            );

            player.sendMessage(
                    ChatColor.GREEN
                            + "You joined the party!"
            );

            for (UUID uuid :
                    party.getMembers()) {

                Player member =
                        Bukkit.getPlayer(uuid);

                if (member == null) {
                    continue;
                }

                if (member.equals(player)) {
                    continue;
                }

                member.sendMessage(
                        ChatColor.GREEN
                                + player.getName()
                                + " joined the party."
                );
            }

            return;
        }

        // LEAVE
        if (action.equals("leave")) {

            Party party =
                    partyManager.getParty(player);

            if (party == null) {

                player.sendMessage(
                        ChatColor.RED
                                + "You are not in a party."
                );

                return;
            }

            boolean wasLeader =
                    party.isLeader(player);

            partyManager.leaveParty(player);

            if (wasLeader) {

                player.sendMessage(
                        ChatColor.YELLOW
                                + "You left the party. The party was disbanded."
                );

            } else {

                player.sendMessage(
                        ChatColor.YELLOW
                                + "You left the party."
                );
            }

            return;
        }

        // KICK
        if (action.equals("kick")) {

            if (args.length < 3) {

                player.sendMessage(
                        ChatColor.RED
                                + "Usage: /skydungeons party kick <player>"
                );

                return;
            }

            Party party =
                    partyManager.getParty(player);

            if (party == null) {

                player.sendMessage(
                        ChatColor.RED
                                + "You are not in a party."
                );

                return;
            }

            if (!party.isLeader(player)) {

                player.sendMessage(
                        ChatColor.RED
                                + "Only the party leader can kick."
                );

                return;
            }

            Player target =
                    Bukkit.getPlayer(args[2]);

            if (target == null) {

                player.sendMessage(
                        ChatColor.RED
                                + "Player is not online."
                );

                return;
            }

            if (!party.isMember(target)) {

                player.sendMessage(
                        ChatColor.RED
                                + "That player is not in your party."
                );

                return;
            }

            if (party.isLeader(target)) {

                player.sendMessage(
                        ChatColor.RED
                                + "You cannot kick yourself."
                );

                return;
            }

            boolean removed =
                    partyManager.kickPlayer(
                            party,
                            target
                    );

            if (!removed) {

                player.sendMessage(
                        ChatColor.RED
                                + "Could not kick that player."
                );

                return;
            }

            player.sendMessage(
                    ChatColor.GREEN
                            + "You kicked "
                            + target.getName()
                            + "."
            );

            target.sendMessage(
                    ChatColor.RED
                            + "You were kicked from the party."
            );

            return;
        }

        // PROMOTE
        if (action.equals("promote")) {

            if (args.length < 3) {

                player.sendMessage(
                        ChatColor.RED
                                + "Usage: /skydungeons party promote <player>"
                );

                return;
            }

            Party party =
                    partyManager.getParty(player);

            if (party == null) {

                player.sendMessage(
                        ChatColor.RED
                                + "You are not in a party."
                );

                return;
            }

            if (!party.isLeader(player)) {

                player.sendMessage(
                        ChatColor.RED
                                + "Only the party leader can promote."
                );

                return;
            }

            Player target =
                    Bukkit.getPlayer(args[2]);

            if (target == null) {

                player.sendMessage(
                        ChatColor.RED
                                + "Player is not online."
                );

                return;
            }

            if (!party.isMember(target)) {

                player.sendMessage(
                        ChatColor.RED
                                + "That player is not in your party."
                );

                return;
            }

            if (target.equals(player)) {

                player.sendMessage(
                        ChatColor.RED
                                + "You are already the leader."
                );

                return;
            }

            partyManager.promotePlayer(
                    party,
                    target
            );

            player.sendMessage(
                    ChatColor.GREEN
                            + target.getName()
                            + " is now the party leader."
            );

            target.sendMessage(
                    ChatColor.GREEN
                            + "You are now the party leader!"
            );

            return;
        }

        sendPartyHelp(player);
    }

    // =========================================================
    // PARTY HELP
    // =========================================================

    private void sendPartyHelp(
            Player player
    ) {

        player.sendMessage(
                ChatColor.DARK_AQUA
                        + "========== Party =========="
        );

        player.sendMessage(
                ChatColor.AQUA
                        + "/skydungeons party create"
        );

        player.sendMessage(
                ChatColor.AQUA
                        + "/skydungeons party invite <player>"
        );

        player.sendMessage(
                ChatColor.AQUA
                        + "/skydungeons party accept"
        );

        player.sendMessage(
                ChatColor.AQUA
                        + "/skydungeons party leave"
        );

        player.sendMessage(
                ChatColor.AQUA
                        + "/skydungeons party kick <player>"
        );

        player.sendMessage(
                ChatColor.AQUA
                        + "/skydungeons party promote <player>"
        );
    }

    // =========================================================
    // TEMPLATE COMMAND
    // =========================================================

    private void handleTemplateCommand(
            CommandSender sender,
            String[] args
    ) {

        if (!(sender instanceof Player player)) {

            sender.sendMessage(
                    ChatColor.RED
                            + "Only players can use template commands."
            );

            return;
        }

        if (args.length < 2) {

            player.sendMessage(
                    ChatColor.RED
                            + "Usage:"
            );

            player.sendMessage(
                    ChatColor.YELLOW
                            + "/skydungeons template create <id>"
            );

            player.sendMessage(
                    ChatColor.YELLOW
                            + "/skydungeons template save <id>"
            );

            return;
        }

        String action =
                args[1].toLowerCase();

        // CREATE
        if (action.equals("create")) {

            if (args.length < 3) {

                player.sendMessage(
                        ChatColor.RED
                                + "Usage: /skydungeons template create <id>"
                );

                return;
            }

            String id =
                    args[2].toLowerCase();

            String worldName =
                    "sd_template_" + id;

            World existingWorld =
                    Bukkit.getWorld(worldName);

            if (existingWorld != null) {

                player.sendMessage(
                        ChatColor.YELLOW
                                + "Template world already loaded: "
                                + ChatColor.WHITE
                                + worldName
                );

                player.teleport(
                        existingWorld.getSpawnLocation()
                );

                return;
            }

            player.sendMessage(
                    ChatColor.YELLOW
                            + "Creating template world..."
            );

            World world =
                    new WorldCreator(worldName)
                            .type(WorldType.NORMAL)
                            .createWorld();

            if (world == null) {

                player.sendMessage(
                        ChatColor.RED
                                + "Could not create template world."
                );

                return;
            }

            player.teleport(
                    world.getSpawnLocation()
            );

            player.sendMessage(
                    ChatColor.GREEN
                            + "Template world created!"
            );

            player.sendMessage(
                    ChatColor.GRAY
                            + "World:"
                            + ChatColor.WHITE
                            + " "
                            + worldName
            );

            player.sendMessage(
                    ChatColor.YELLOW
                            + "Build your dungeon here."
            );

            player.sendMessage(
                    ChatColor.YELLOW
                            + "When finished use:"
            );

            player.sendMessage(
                    ChatColor.WHITE
                            + "/skydungeons template save "
                            + id
            );

            return;
        }

        // SAVE
        if (action.equals("save")) {

            if (args.length < 3) {

                player.sendMessage(
                        ChatColor.RED
                                + "Usage: /skydungeons template save <id>"
                );

                return;
            }

            String id =
                    args[2].toLowerCase();

            saveTemplate(
                    player,
                    id
            );

            return;
        }

        player.sendMessage(
                ChatColor.RED
                        + "Unknown template command."
        );
    }

    // =========================================================
    // SAVE TEMPLATE
    // =========================================================

    private void saveTemplate(
            Player player,
            String id
    ) {

        String worldName =
                "sd_template_" + id;

        World world =
                Bukkit.getWorld(worldName);

        if (world == null) {

            player.sendMessage(
                    ChatColor.RED
                            + "Template world is not loaded."
            );

            player.sendMessage(
                    ChatColor.GRAY
                            + "Expected world:"
                            + ChatColor.WHITE
                            + " "
                            + worldName
            );

            return;
        }

        player.sendMessage(
                ChatColor.YELLOW
                        + "Saving template..."
        );

        // -----------------------------------------------------
        // Find another world
        // -----------------------------------------------------

        World mainWorld = null;

        for (World loadedWorld :
                Bukkit.getWorlds()) {

            if (!loadedWorld.getName()
                    .equalsIgnoreCase(worldName)) {

                mainWorld = loadedWorld;

                break;
            }
        }

        if (mainWorld == null) {

            player.sendMessage(
                    ChatColor.RED
                            + "Could not find another loaded world."
            );

            return;
        }

        // -----------------------------------------------------
        // Move everyone out
        // -----------------------------------------------------

        List<Player> playersInTemplate =
                new ArrayList<>(
                        world.getPlayers()
                );

        for (Player templatePlayer :
                playersInTemplate) {

            templatePlayer.teleport(
                    mainWorld.getSpawnLocation()
            );

            templatePlayer.sendMessage(
                    ChatColor.YELLOW
                            + "You were moved out of the template world."
            );
        }

        // -----------------------------------------------------
        // Save
        // -----------------------------------------------------

        try {

            world.save();

        } catch (Exception exception) {

            player.sendMessage(
                    ChatColor.RED
                            + "Could not save template world."
            );

            getLogger().severe(
                    "Template save error: "
                            + exception.getMessage()
            );

            return;
        }

        File sourceFolder =
                world.getWorldFolder();

        if (sourceFolder == null
                || !sourceFolder.exists()) {

            player.sendMessage(
                    ChatColor.RED
                            + "Template world folder was not found."
            );

            return;
        }

        // -----------------------------------------------------
        // Unload
        // -----------------------------------------------------

        boolean unloaded;

        try {

            unloaded =
                    Bukkit.unloadWorld(
                            world,
                            true
                    );

        } catch (Exception exception) {

            player.sendMessage(
                    ChatColor.RED
                            + "Error while unloading template world."
            );

            getLogger().severe(
                    "Template unload error: "
                            + exception.getMessage()
            );

            return;
        }

        if (!unloaded) {

            player.sendMessage(
                    ChatColor.RED
                            + "Could not unload template world."
            );

            return;
        }

        player.sendMessage(
                ChatColor.GREEN
                        + "Template world unloaded."
        );

        // -----------------------------------------------------
        // Template folder
        // -----------------------------------------------------

        File templatesFolder =
                new File(
                        Bukkit.getWorldContainer(),
                        "dungeon_templates"
                );

        if (!templatesFolder.exists()) {

            if (!templatesFolder.mkdirs()) {

                player.sendMessage(
                        ChatColor.RED
                                + "Could not create dungeon_templates folder."
                );

                return;
            }
        }

        File destinationFolder =
                new File(
                        templatesFolder,
                        id
                );

        // -----------------------------------------------------
        // Remove old template
        // -----------------------------------------------------

        if (destinationFolder.exists()) {

            player.sendMessage(
                    ChatColor.YELLOW
                            + "Removing old template..."
            );

            deleteFolder(
                    destinationFolder
            );
        }

        // -----------------------------------------------------
        // Copy
        // -----------------------------------------------------

        player.sendMessage(
                ChatColor.YELLOW
                        + "Copying template files..."
        );

        try {

            copyFolder(
                    sourceFolder.toPath(),
                    destinationFolder.toPath()
            );

        } catch (Exception exception) {

            player.sendMessage(
                    ChatColor.RED
                            + "Could not copy template."
            );

            getLogger().severe(
                    "Template copy error: "
                            + exception.getMessage()
            );

            return;
        }

        player.sendMessage(
                ChatColor.GREEN
                        + "================================"
        );

        player.sendMessage(
                ChatColor.GREEN
                        + "Template saved successfully!"
        );

        player.sendMessage(
                ChatColor.GRAY
                        + "ID: "
                        + ChatColor.WHITE
                        + id
        );

        player.sendMessage(
                ChatColor.GRAY
                        + "Location: "
                        + ChatColor.WHITE
                        + "dungeon_templates/"
                        + id
        );

        player.sendMessage(
                ChatColor.GREEN
                        + "================================"
        );
    }

    // =========================================================
    // COPY FOLDER
    // =========================================================

    private void copyFolder(
            Path source,
            Path destination
    ) throws IOException {

        if (!Files.exists(source)) {

            throw new IOException(
                    "Source folder does not exist: "
                            + source
            );
        }

        try (
                var stream =
                        Files.walk(source)
        ) {

            stream.forEach(path -> {

                try {

                    Path relative =
                            source.relativize(path);

                    Path target =
                            destination.resolve(relative);

                    if (Files.isDirectory(path)) {

                        Files.createDirectories(
                                target
                        );

                    } else {

                        Path parent =
                                target.getParent();

                        if (parent != null) {

                            Files.createDirectories(
                                    parent
                            );
                        }

                        Files.copy(
                                path,
                                target,
                                StandardCopyOption.REPLACE_EXISTING
                        );
                    }

                } catch (IOException exception) {

                    throw new RuntimeException(
                            exception
                    );
                }
            });
        }
    }

    // =========================================================
    // DELETE FOLDER
    // =========================================================

    private void deleteFolder(
            File folder
    ) {

        if (folder == null
                || !folder.exists()) {

            return;
        }

        File[] files =
                folder.listFiles();

        if (files != null) {

            for (File file :
                    files) {

                if (file.isDirectory()) {

                    deleteFolder(file);

                } else {

                    try {

                        Files.deleteIfExists(
                                file.toPath()
                        );

                    } catch (IOException exception) {

                        getLogger().warning(
                                "Could not delete file: "
                                        + file.getAbsolutePath()
                        );
                    }
                }
            }
        }

        try {

            Files.deleteIfExists(
                    folder.toPath()
            );

        } catch (IOException exception) {

            getLogger().warning(
                    "Could not delete folder: "
                            + folder.getAbsolutePath()
            );
        }
    }

    // =========================================================
    // TAB COMPLETE
    // =========================================================

    @Override
    public List<String> onTabComplete(
            CommandSender sender,
            Command command,
            String alias,
            String[] args
    ) {

        List<String> suggestions =
                new ArrayList<>();

        if (!command.getName()
                .equalsIgnoreCase("skydungeons")) {

            return suggestions;
        }

        // /skydungeons <command>
        if (args.length == 1) {

            suggestions.add("help");
            suggestions.add("list");
            suggestions.add("stages");
            suggestions.add("party");
            suggestions.add("enter");
            suggestions.add("template");

            return filter(
                    suggestions,
                    args[0]
            );
        }

        // /skydungeons enter <id>
        if (args.length == 2
                && args[0]
                .equalsIgnoreCase("enter")) {

            for (Dungeon dungeon :
                    dungeonManager.getDungeons()) {

                suggestions.add(
                        dungeon.getId()
                );
            }

            return filter(
                    suggestions,
                    args[1]
            );
        }

        // /skydungeons stages <id>
        if (args.length == 2
                && args[0]
                .equalsIgnoreCase("stages")) {

            for (Dungeon dungeon :
                    dungeonManager.getDungeons()) {

                suggestions.add(
                        dungeon.getId()
                );
            }

            return filter(
                    suggestions,
                    args[1]
            );
        }

        // PARTY
        if (args.length == 2
                && args[0]
                .equalsIgnoreCase("party")) {

            suggestions.add("create");
            suggestions.add("invite");
            suggestions.add("accept");
            suggestions.add("leave");
            suggestions.add("kick");
            suggestions.add("promote");

            return filter(
                    suggestions,
                    args[1]
            );
        }

        // PARTY PLAYER
        if (args.length == 3
                && args[0]
                .equalsIgnoreCase("party")
                && (
                args[1].equalsIgnoreCase("invite")
                        || args[1].equalsIgnoreCase("kick")
                        || args[1].equalsIgnoreCase("promote")
        )) {

            for (Player online :
                    Bukkit.getOnlinePlayers()) {

                suggestions.add(
                        online.getName()
                );
            }

            return filter(
                    suggestions,
                    args[2]
            );
        }

        // TEMPLATE
        if (args.length == 2
                && args[0]
                .equalsIgnoreCase("template")) {

            suggestions.add("create");
            suggestions.add("save");

            return filter(
                    suggestions,
                    args[1]
            );
        }

        return suggestions;
    }

    // =========================================================
    // FILTER
    // =========================================================

    private List<String> filter(
            List<String> values,
            String input
    ) {

        List<String> result =
                new ArrayList<>();

        for (String value :
                values) {

            if (value.toLowerCase()
                    .startsWith(
                            input.toLowerCase()
                    )) {

                result.add(value);
            }
        }

        return result;
    }

    // =========================================================
    // GETTERS
    // =========================================================

    public PartyManager getPartyManager() {
        return partyManager;
    }

    public PartyInviteManager getPartyInviteManager() {
        return partyInviteManager;
    }

    public DungeonManager getDungeonManager() {
        return dungeonManager;
    }

    public DungeonInstanceManager getDungeonInstanceManager() {
        return dungeonInstanceManager;
    }
}